from Neuron import Neuron
# import matplotlib.pyplot as plt
import math
import json

def array_average(array):
    sum = 0
    for i in array:
        sum += i
    return sum / len(array)

neuron = Neuron(2)

dataset = json.loads(open('dataset.json').read())

average_errors = []

for x in range(1, 1000):
    errors = []
    for fruit in dataset:
        inputs = [fruit['masse'], fruit['diametre']]
        errors.append(math.fabs(neuron.train(inputs, fruit['type'])))
    average_errors.append(array_average(errors))
    print('Entrainement n°', x, 'erreur moyenne :', array_average(errors))

print('Entrainement terminé')
print('Bias : ' + str(neuron.bias))

"""
plt.plot(average_errors)
plt.ylabel('Erreur moyenne')
plt.xlabel('Nombre d\'entrainement')
plt.title('Evolution du neurone')
plt.show()
"""
