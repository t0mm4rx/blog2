import random

class Neuron:

    def __init__(self, inputs_n):
        self.learning_rate = 0.1
        self.weights = []
        self.bias = 0
        self.init_weights(inputs_n)

    # Fonction d'activation, x: float
    def activate(self, x):
        if x >= 0:
            return 1
        else:
            return 0

    # Fonction de prédiction, inputs: float[], retourne la prédiction, 0 (pomme) ou 1 (citron)
    def guess(self, inputs):
        sum = 0
        for i in range(0, len(inputs)):
            sum += self.weights[i] * inputs[i]
        sum += self.bias
        return self.activate(sum)

    # Fonction d'entrainement, input: float[], output: float, retourne l'erreur
    def train(self, inputs, output):
        # On réalise une prédiction
        guess = self.guess(inputs)
        # On calcul l'écart entre notre prédiction et la réponse attendue
        error = output - guess
        # On corrige chacun des poids
        for i in range(0, len(self.weights)):
            self.weights[i] += error * inputs[i] * self.learning_rate
        self.bias += error * self.learning_rate
        return error

    # Fonction d'initialisation des poids, on crée le tableau de dimension inputs_n et on le rempli de valeurs aléatoires entre -1 et 1
    def init_weights(self, inputs_n):
        for i in range(0, inputs_n):
            self.weights.append(random.uniform(-1, 1))
